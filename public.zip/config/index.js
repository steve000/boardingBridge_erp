window.airportConfig = {
  api: {
    // baseUrl: "http://172.23.162.10:3000/api",
    // baseUrl: "http://1616d788a5.iok.la:23275/api",
    baseUrl: "http://172.23.162.6:3000/api",
    // baseUrl: "http://22385a17n3.51mypc.cn:30972//api", // 6的外网
    // baseUrl: "http://47.92.200.142:9999/api",
    menuListUrl:"./mock/menu.json"
  },
  container: {
    visiblePath: []
  },
  base:{
    title:"登机桥运营监测管理系统"
  }
}
